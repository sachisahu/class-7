package com.sachi.russiaregionals;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttp;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends AppCompatActivity {

    Button btnSignIn,btnRegister;
    EditText etEmail,etPass;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnRegister = findViewById(R.id.btnRegister);
        btnSignIn = findViewById(R.id.btnSignIn);
        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPassword);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etEmail.getText().length()>0 && etPass.getText().length()>0){
                    userSignIn(""+etEmail.getText().toString(),""+etPass.getText().toString());
                }

            }
        });

    }

    private void userSignIn(String email, String password) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("email",""+email);
            jsonObject.put("password",""+password);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(jsonObject.toString(), MediaType.parse("application/json"));
        Request request = new Request.Builder().url("http://mskko2021.mad.hakta.pro/api/user/login").post(body).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.d("Api","Failed"+e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if(response.isSuccessful()){
                    String str = response.body().string();
                    Log.d("Api",str+"");
                    try {
                        JSONObject object = new JSONObject(str);
                        String id = object.get("id").toString();
                        String email = object.get("email").toString();
                        String nickName = object.get("nickName").toString();
                        String avatar = object.get("avatar").toString();
                        String token = object.get("token").toString();

                        utilSp.saveString(LoginActivity.this,"userData","id",id);
                        utilSp.saveString(LoginActivity.this,"userData","email",email);
                        utilSp.saveString(LoginActivity.this,"userData","nickName",nickName);
                        utilSp.saveString(LoginActivity.this,"userData","avatar",avatar);
                        utilSp.saveString(LoginActivity.this,"userData","pass",password);
                        utilSp.saveString(LoginActivity.this,"userData","token",token);


                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                startActivity(new Intent(LoginActivity.this,BottomNavActivity.class));

                            }
                        });



                        Log.d("Api ID",object.get("id")+"");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }
        });
    }


}