package com.sachi.russiaregionals.ui.home;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sachi.russiaregionals.R;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ListDataAdapter extends RecyclerView.Adapter<ListDataAdapter.MyViewHolder> {

    private List<com.sachi.russiaregionals.ui.home.listData> listD;



    public ListDataAdapter(List<com.sachi.russiaregionals.ui.home.listData> list) {
        this.listD = list;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.horizontal_scroll,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        listData list = listD.get(position);
        holder.title.setText(list.getTitle());
        Bitmap bitmap = loadimage(list.getImage());
        holder.image.setImageBitmap(bitmap);


    }

    private Bitmap loadimage(String image) {
        final Bitmap[] bitmap = new Bitmap[1];
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(image).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                byte[] bytes = response.body().bytes();
                bitmap[0] = BitmapFactory.decodeByteArray(bytes,0, bytes.length);

            }
        });

        return bitmap[0];
    }

    @Override
    public int getItemCount() {
        return listD.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
            TextView title;
            ImageView image;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.titleName);
            image = itemView.findViewById(R.id.imageL);
        }
    }



}
