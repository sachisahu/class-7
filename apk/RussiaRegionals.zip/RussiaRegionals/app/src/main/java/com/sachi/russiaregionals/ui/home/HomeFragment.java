package com.sachi.russiaregionals.ui.home;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sachi.russiaregionals.R;
import com.sachi.russiaregionals.databinding.FragmentHomeBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class HomeFragment extends Fragment {


    private FragmentHomeBinding binding;
    ImageView imageView;
    List<listData> list = new ArrayList<>();
    private ListDataAdapter mAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        imageView = root.findViewById(R.id.imageProfile);


        //Charset charset = StandardCharsets.US_ASCII;
        String strURL = utilSp.getString(getActivity(),"userData","avatar").toString();
        loadImage(strURL);

        RecyclerView recyclerView = root.findViewById(R.id.RVList);
        mAdapter = new ListDataAdapter(list);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        manager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(manager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);
        loadData();






        return root;
    }

    private void loadData() {


        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url("http://mskko2021.mad.hakta.pro/api/feelings").build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                String str = response.body().string();
                Log.d("Feelings",str+"");
                try {
                    JSONObject jsonObjectMain = new JSONObject(str);
                    String data = jsonObjectMain.getString("data");
                    JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                    for(int i = 0;i< jsonArray.length();i++){
                        JSONObject jsonObjectFeelings = new JSONObject(jsonArray.getString(i));
                        String id = jsonObjectFeelings.getString("id");
                        String title = jsonObjectFeelings.getString("title");
                        String position = jsonObjectFeelings.getString("position");
                        String image = jsonObjectFeelings.getString("image");

                        Log.d("Images",image);


                        listData listData = new listData(id+"",title+"",""+image,""+position);
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                list.add(listData);
                                mAdapter.notifyDataSetChanged();
                            }
                        });


                        Log.d("Feelings Title",jsonObjectFeelings.getString("title"));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });

    }

    private void loadImage(String strURL) {


        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(strURL).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {

                byte[] bytes =  response.body().bytes();
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0, bytes.length);

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imageView.setImageBitmap(bitmap);
                    }
                });
            }

        });
    }

}